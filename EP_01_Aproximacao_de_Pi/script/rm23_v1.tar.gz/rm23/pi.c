#include "pi.h"

void arredondar (ldouble valor, int casas_decimais) {
    DOUBLE_HEXA hex_baixo, hex_cima;

    ldouble fator = pow(10, casas_decimais);

    int ulps;

    fesetround(FE_TOWARDZERO);
    hex_baixo.value = ((valor*fator) / fator);
    printf("%.15Le %016lX\n", hex_baixo.value, hex_baixo.hexa);

    fesetround(FE_TONEAREST);
    hex_cima.value = ((valor*fator) / fator);
    printf("%.15Le %016lX\n", hex_cima.value, hex_cima.hexa);

    ulps = ABS(hex_cima.hexa, hex_baixo.hexa);
    printf("%d\n", ulps);

}

ldouble somatoria (ldouble tolerancia) {
    ll it = 0;
    //printf("it = %lld\n", it);
    ldouble pow_2k = 1; // 2^k
    ldouble fat_k = 1; // k!
    ldouble fat_Denominador = 1; // (2k + 1)!
    ldouble sum = 0.0;
    ldouble termo, pi_anterior, diff;

    DOUBLE_HEXA diference, pi;

    do {
        termo = ((pow_2k*fat_k*fat_k) / fat_Denominador);
        pi_anterior = sum;
        sum += termo;
        it++;
        fat_k *= it;
        pow_2k *= 2;
        fat_Denominador *= (2*it) * (2*it + 1);
        diff = ABS(sum, pi_anterior)*2;
        // printf("valor diff = %.15Le\n", sum);
    } while (diff > tolerancia);
    // printf("valor diff = %.15e\n", diff); 
    diference.value = diff;
    pi.value = ABS(sum*2, M_PI);
    printf("%lld\n", it);
    printf("%.15Le %016lX\n", diference.value, diference.hexa);
    printf("%.15Le %016lX\n", ABS(sum*2, M_PI), pi.hexa);
    return sum*2;
}

void aproxima_pi (ldouble tolerancia) {
    
    ldouble pi_aproximado;

    pi_aproximado = somatoria(tolerancia);
    // printf("pi = %.15e\n", pi_aproximado);
    arredondar(pi_aproximado, CASA_D);
    return;
}

int main() {
    double entrada;
    scanf("%lf", &entrada);
    // printf("entrada = %.15e\n", entrada);
    aproxima_pi(entrada);
    return 0;
}