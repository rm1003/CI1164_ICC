#ifndef _PI_
#define _PI_

#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>
#include <fenv.h>
#include <stdint.h>

#define ll long long
#define ull unsigned long long
#define ldouble long double

#define CASA_D 15

#define ABS(a, b) ((a > b) ? a - b : b - a)

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef union{
    ldouble value;
    uint64_t hexa;
} DOUBLE_HEXA;

void arredondar (ldouble valor, int casas_decimais);

ldouble somatoria (ldouble tolerancia);

void aproxima_pi (ldouble tolerancia);


#endif /* pi.h */